var PLAY = 1;
var END = 0;
var GameState = PLAY;

var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var FoodGroup, obstacleGroup;
var score = 0;

function preload(){
  
  
monkey_running =           loadAnimation("monkey_0.png","monkey_1.png","monkey_2.png","monkey_3.png","monkey_4.png","monkey_5.png","monkey_6.png","monkey_7.png","monkey_8.png")
bananaImage = loadImage("banana.png");
obstacleImage = loadImage("obstacle.png");

}



function setup() {
createCanvas(400, 400);
 
//creating monkey
monkey=createSprite(50,355,20,20);
monkey.addAnimation("moving", monkey_running);
monkey.scale=0.1;

ground = createSprite(200,390,400,20);
obstacleGroup = new Group();
FoodGroup = new Group();
  
}


function draw() {
  
  background(255);
  text(score, 200, 50);
  
    
  if(keyDown("space") && monkey.y >= 159) {
      monkey.velocityY = -12;
    }
  monkey.velocityY = monkey.velocityY + 0.8;
  monkey.collide(ground);
  spawnObstacles();
  if(FoodGroup.isTouching(monkey)) {
  score = score + 1;
  FoodGroup.destroyEach();
  }
  if (obstacleGroup.isTouching(monkey)) {
  monkey.destroy();
  score = 0;
  }
  drawSprites(); 
}

function spawnObstacles() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600,365,10,40);
    //obstacle.debug = true;
    obstacle.addImage(obstacleImage);
    banana = createSprite(610, 280);
    banana.addImage("Bananaimage", bananaImage);
    banana.scale = 0.1;
    obstacle.scale = 0.1;
    obstacle.lifetime = 300;
    obstacle.velocityX = -(6 + 3*score/100);
    banana.velocityX = -(6 + 3*score/100);
    obstacleGroup.add(obstacle);
    banana.lifetime = 300;
    FoodGroup.add(banana);
  }
}
  


